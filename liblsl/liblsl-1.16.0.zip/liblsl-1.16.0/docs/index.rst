liblsl documentation
====================

This is the in-progress API documentation for liblsl.

The complete labstreaminglayer documentation with concepts, a
:doc:`quickstart guide <lsl:info/getting_started>`
and links to precompiled packages is at the :doc:`lsl:index`.


.. toctree::
   :maxdepth: 1
   :caption: API reference:
   :glob:

   ref/*


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


